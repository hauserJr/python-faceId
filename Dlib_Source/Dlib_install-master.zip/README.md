# Install Dlib for Anaconda Python in Windows

In Anaconda Prompt of Windows /<br>
在 Anaconda Prompt 窗口 :
 
  Input following cmd to install the newest pip /<br> 
  安装最新版本的 pip :

  > $ python get-pip.py
  
<br>

  Input following cmd to install Dlib / <br>
  利用 pip 安装 Dlib 的 whl :
  > $ pip install dlib-19.7.0-cp36-cp36m-win_amd64.whl

<br><br>
Author: &nbsp; coneypo 
<br>
Mail: &nbsp;&nbsp;coneypo@foxmail.com
